var Hapi = Hapi || {};

let HANDPOINT_SDK_VERSION = "1.3";

/**
 * Creates an instance of the V1 of Hapi
 * @param client_id A unique identifier of your system to group operations
 * @param ssk The shared secret key to authorize the operations
 * @param auto_return Boolean value, If true, Handpoint Express automatically switches back to your app following a short timeout after the transaction completes.
 * @param auto_return_timeout Integer value, the time the app would wait until it triggers the auto_return. @param auto_return should be true to use this.
 */
function initHapiExpress(client_id, ssk, auto_return, auto_return_timeout) {
    Hapi = (function () {
        let APP_NAME = "express";
        let SCHEME = "handpoint";
        let PROTOCOL_VERSION = "v1";

        function buildURL(data) {
            console.log(data);
            return SCHEME + "://" + APP_NAME + "/" + PROTOCOL_VERSION + "/?data=" + encodeURIComponent(data);
        }

        function buildDataJSONString(action, parameters, extra_parameters, callback_url) {
            let data = {
                action: {
                    type: action,
                    parameters: parameters,
                    extraParameters: extra_parameters
                },
                client: {
                    clientId: client_id,
                    ssk: ssk,
                    autoReturn: auto_return,
                    autoReturnTimeout: auto_return_timeout
                },
                callbackUrl: callback_url
            };

            return JSON.stringify(data, null, '\t');
        }

        let actionTypes = {
            sale: "sale",
            saleAndTokenizeCard: "saleAndTokenizeCard",
            tokenizeCard: "tokenizeCard",
            refund: "refund",
            refund_reversal: "refundReversal",
            sale_reversal: "saleReversal",
            enable_scanner: "enableScanner"
        };

        return {
            /**
             * <p>Transactions are operations performed with a device, We provide 2 different methods (which differ in
             * parameters being passed) for each transaction type to serve different needs of the integrator.
             * The different parameters are: regular parameters (BigInteger, Currencies) and an optional Map object
             * All operations report to the <code>onHapiEvent</code> listener with the type <code>TransactionStatusChanged</code> </p>
             * When a transaction is finished <code>TransactionFinished</code> is called.
             *
             * All transactions operations require "Amount":1000 and "Currencies":Currencies.ISK. If a transaction is to be reversed then a
             * "OriginalTransactionID" is also required. Additional parameters for the transaction can be put to a map and passed on.
             * Example: hapi.sale(1000, Currencies.ISK); - this will start a transaction of 10.00kr to the default card reader
             */

            /**
             * Sale operation using regular parameters
             * Amount 1000 with Currencies.USD amounts to $10.00.
             * @param amount The amount to be used
             * @param currency The currency to be used
             * @param extra_parameters An object containing additional sale parameters, fx. Key: "Budget", Value: "03"
             * @param callback_url The URL that Handpoint Express will send its response to.
             */
            urlForSale: function (amount, currency, extra_parameters, callback_url) {
                let params = {
                    amount: amount,
                    currency: currency
                };

                let data = buildDataJSONString(actionTypes.sale, params, extra_parameters, callback_url);

                return buildURL(data);
            },

            /**
             * Sale And Tokenize Card operation using regular parameters
             * Amount 1000 with Currencies.USD amounts to $10.00.
             * @param amount The amount to be used
             * @param currency The currency to be used
             * @param extra_parameters An object containing additional sale parameters, fx. Key: "Budget", Value: "03"
             * @param callback_url The URL that Handpoint Express will send its response to.
             */
            urlForSaleAndTokenizeCard: function (amount, currency, extra_parameters, callback_url) {
                let params = {
                    amount: amount,
                    currency: currency
                };

                let data = buildDataJSONString(actionTypes.saleAndTokenizeCard, params, extra_parameters, callback_url);

                return buildURL(data);
            },

            /**
             * Tokenize Card operation
             * @param extra_parameters An object containing additional sale parameters, fx. Key: "Budget", Value: "03"
             * @param callback_url The URL that Handpoint Express will send its response to.
             */
            urlForTokenizeCard: function (extra_parameters, callback_url) {
                let data = buildDataJSONString(actionTypes.tokenizeCard, {}, extra_parameters, callback_url);

                return buildURL(data);
            },

            /**
             * Refund operation on a default device using regular parameters
             * Additional transaction parameters can be sent with the extra_parameters object
             * Amount 1000 with Currencies.USD amounts to $10.00.
             * @param amount The amount to be used
             * @param currency The currency to be used
             * @param extra_parameters An object containing additional refund parameters.
             * @param callback_url The URL that Handpoint Express will send its response to.
             */
            urlForRefund: function (amount, currency, extra_parameters, callback_url) {
                let params = {
                    amount: amount,
                    currency: currency
                };

                let data = buildDataJSONString(actionTypes.refund, params, extra_parameters, callback_url);

                return buildURL(data);
            },

            /**
             * Refund reversal operation on a default device using regular parameters and a map object
             * Additional transaction parameters can be sent with the extra_parameters object.
             * Amount 1000 with Currencies.USD amounts to $10.00.
             * @param amount The amount to be used
             * @param currency The currency to be used
             * @param originalTransactionID The EFTtransactionID as received from the card reader (EFTTransactionID)
             * @param extra_parameters An object containing additional parameters
             * @param callback_url The URL that Handpoint Express will send its response to.
             */
            urlForRefundReversal: function (amount, currency, originalTransactionID, extra_parameters, callback_url) {
                let params = {
                    amount: amount,
                    currency: currency,
                    originalTransactionID: originalTransactionID
                };

                let data = buildDataJSONString(actionTypes.refund_reversal, params, extra_parameters, callback_url);

                return buildURL(data);
            },

            /**
             * Sale reversal operation on a default device using regular parameters
             * Additional transaction parameters can be sent with the extra_parameters object.
             * Amount 1000 with Currencies.USD amounts to $10.00.
             * @param amount The amount to be used
             * @param currency The currency to be used
             * @param originalTransactionID The EFTtransactionID as received from the card reader (EFTTransactionID)
             * @param extra_parameters An object containing additional parameters
             * @param callback_url The URL that Handpoint Express will send its response to.
             */
            urlForSaleReversal: function (amount, currency, originalTransactionID, extra_parameters, callback_url) {
                let params = {
                    amount: amount,
                    currency: currency,
                    originalTransactionID: originalTransactionID
                };

                let data = buildDataJSONString(actionTypes.sale_reversal, params, extra_parameters, callback_url);

                return buildURL(data);
            },

            /**
             * Use Scanner operation enables the scanner setting the behaviour with the following parameters
             * Additional transaction parameters can be sent with the extra_parameters object.
             * @param multiScan true if you want to scan multiple items before returning to your app.
             * @param autoScan true if you want the scanner always on without the pushing of a button
             * @param resultsGrouped true if you want scans from a multi scan to come all together when you're finished.
             * @param timeout the amount of seconds until the scanner shuts itself off. Default is 0
             * @param extra_parameters An object containing additional parameters
             * @param callback_url The URL that Handpoint Express will send its response to.
             */
            urlForScanner: function (multiScan, autoScan, resultsGrouped, timeout, extra_parameters, callback_url) {
                let params = {
                    multiScan: multiScan,
                    autoScan: autoScan,
                    resultsGrouped: resultsGrouped,
                    timeout: timeout
                };

                let data = buildDataJSONString(actionTypes.enable_scanner, params, extra_parameters, callback_url);

                return buildURL(data);
            },

            /**
             * Opens the url passed
             * @param url The url to be used
             */
            openUrl: function (url) {
                document.location = url;
                console.log(url);
            }

        };
    }());
}
